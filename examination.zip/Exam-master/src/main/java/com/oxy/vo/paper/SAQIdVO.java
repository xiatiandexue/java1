package com.oxy.vo.paper;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SAQIdVO {
	private String saqids;
	private Integer saqid;
	private Integer paperid;
}
