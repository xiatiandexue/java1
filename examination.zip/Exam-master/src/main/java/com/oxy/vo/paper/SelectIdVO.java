package com.oxy.vo.paper;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SelectIdVO {
	private String questionids;
	private Integer questionid;
	private Integer paperid;
}
