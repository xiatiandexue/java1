package com.oxy.vo;

import lombok.Data;

/**
 * @author lil1
 * @date 2019年4月16日 下午4:38:05
 * @Description 
 */
@Data
public class BasePageVO {
	private int pageNum;
	
	private int PageSize;
}
