package com.oxy.vo.paper;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class PaperIdVO {
	private Integer paperid;

	
}
