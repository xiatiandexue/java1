package com.oxy.vo.paper;

import lombok.Data;

@Data
public class PagePaperVO {
	private String subject;
	private String createuser;
	private Integer pageNum;
	private Integer pageSize;
}
