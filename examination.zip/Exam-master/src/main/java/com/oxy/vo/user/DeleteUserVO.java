package com.oxy.vo.user;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DeleteUserVO {
 private String usercode;
}
