package com.oxy.vo.itemBank;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DeleteSaqVO {
	private Integer saqid;
}
