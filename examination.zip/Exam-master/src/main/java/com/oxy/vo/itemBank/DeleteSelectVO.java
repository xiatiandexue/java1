package com.oxy.vo.itemBank;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class DeleteSelectVO {
	private Integer questionid;
}
